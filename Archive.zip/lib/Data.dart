import 'package:flutter/material.dart';

Color primaryColor = const Color(0xFFCADCED);
Color XtextColor = Color.fromARGB(172, 0, 157, 149);
Color OtextColor = Color.fromARGB(172, 141, 1, 31);

List<BoxShadow> customShadow = [
  BoxShadow(
    color: Colors.white.withOpacity(0.5),
    spreadRadius: -2,
    offset: const Offset(-2, -2),
    blurRadius: 20
  ),
  BoxShadow(
    color: Colors.blue[900]!.withOpacity(.2),
    spreadRadius: 2,
    offset: const Offset(7,7),
    blurRadius: 20
  )
];


List expenses = [
  {"name": "Groceries", "amount": 500.0},
  {"name": "Online Shopping", "amount": 100.0},
  {"name": "Eating Out", "amount": 80.0},
  {"name": "Bills", "amount": 50.0},
  {"name": "Subscriptions", "amount": 100.0},
  {"name": "Fees", "amount": 30.0},
];

 List pieColors = [
  Colors.indigo[400],
  Colors.blue,
  Colors.amber,
  Colors.deepOrange,
  Colors.brown,
  Colors.green,
];


class XandOBO{
  Color backgroundColor = primaryColor;
  String textValue = "";
  XandOBO({required this.backgroundColor, required this.textValue});
}

final ButtonStyle raisedButtonStyle = OutlinedButton.styleFrom(
  backgroundColor: Colors.black87,
  
  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
  shape: const RoundedRectangleBorder(
  borderRadius: BorderRadius.all(Radius.circular(30)),
  ),
);
 

class AppTheme {
  AppTheme._();
  
  static final ThemeData lightTheme = ThemeData(
    primaryColor:  const Color(0xFFCADCED),
    
    brightness: Brightness.light,
    textTheme: const TextTheme(
      subtitle1: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold),
      subtitle2: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)
    ),
    
  );

  static final ThemeData darkTheme = ThemeData(
    primaryColor: Colors.black,
    brightness: Brightness.dark,
    textTheme: const TextTheme(
      subtitle1: TextStyle(color: Color(0xFFCADCED), fontSize: 18, fontWeight: FontWeight.bold),
      subtitle2: TextStyle(color: Color(0xFFCADCED), fontSize: 24, fontWeight: FontWeight.bold)),
  );
}

 
// class AppStateNotifier extends ChangeNotifier {
//   //
//   bool isDarkMode = false;
 
//   void updateTheme(bool isDarkMode) {
//     this.isDarkMode = isDarkMode;
//     notifyListeners();
//   }
// }