package com.example.firtter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
